# Origine et dépendances

Portage Ubuntu de MonitorBar à partir de la version macOS fournie par son propriétaire.
La version macOS d’origine n’est pas incluse ni modifiée. Cette version conserve ses
fonctions et son style général, avec une interface Qt et des mesures Linux.

Aucune licence explicite n’était présente dans le projet macOS fourni. Aucune licence
open source ni cession des droits sur le logiciel d’origine n’est présumée ici. Le
propriétaire peut distribuer ce paquet et doit préciser les conditions de réutilisation
des sources lors d’une publication publique.

Python et PyQt5 sont installés séparément depuis Ubuntu, et ne sont pas embarqués.
PyQt5 : https://www.riverbankcomputing.com/software/pyqt/
Qt : https://www.qt.io/licensing/
Les outils des pilotes NVIDIA, AMD et Intel restent des composants externes.
