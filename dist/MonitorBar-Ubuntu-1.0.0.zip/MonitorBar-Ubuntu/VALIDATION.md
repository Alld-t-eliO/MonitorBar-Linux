# Validation de la version 1.0.0

## Vérifications locales

Le 6 octobre 2026, sur macOS avec Python 3.14 et PyQt5 5.15.11 :

- **13 tests automatisés réussis**, dont les trois tests d’interface Qt en mode hors écran.
- Syntaxe Python et scripts shell vérifiée.
- Structure du `.deb` contrôlée par le lecteur de tests et par l’outil système `ar`.
- ZIP lu sans erreur ; permissions du lanceur et dépendances du paquet contrôlées.
- Rendu du thème Néon avec trois courbes inspecté visuellement ; illustration dans
  `preview.png`. Les valeurs de cette illustration sont simulées.

Aucune installation réelle Ubuntu n’a été exécutée sur cette machine. Docker est
installé mais son moteur n’est pas lancé. Les tests d’interface hors écran sur Mac
ne valident pas le comportement d’un bureau Ubuntu ni les capteurs GPU physiques.
Le workflow Ubuntu fourni n’a pas encore été exécuté.

## Recette restante sur Ubuntu

Sur Ubuntu 22.04 et 24.04, avec un vrai bureau :

1. Installer le `.deb` avec APT sur une machine sans PyQt5 préinstallé ; ouvrir MonitorBar
   depuis Applications et depuis le terminal. Vérifier la désinstallation.
2. Comparer CPU et RAM à un moniteur système utilisant la même définition des compteurs.
3. Tester NVIDIA, AMD et Intel : repos, charge, pilote absent, permissions refusées,
   plusieurs GPU et changement de carte. Vérifier que l’indisponibilité donne un tiret.
4. Tester les trois dispositions, tous les thèmes, couleurs, opacité, icônes et courbes.
5. Déplacer, aligner, redimensionner aux deux limites, verrouiller et déverrouiller.
6. Masquer / réordonner, relancer et vérifier position et réglages. Débrancher un écran
   pour vérifier que la barre reste accessible.
7. Vérifier X11 et XWayland : transparence, menu, plein écran, bureaux virtuels et icône.
   Le gestionnaire de fenêtres peut limiter les comportements d’une fenêtre flottante.
8. Activer puis désactiver le démarrage automatique et fermer la session pour vérifier.

## Couverture automatisée fournie

- Compteurs CPU : différences, première lecture, remise à zéro, exclusion du double
  comptage des ticks invités.
- RAM : mémoire disponible, compteur absent / nul.
- GPU : valeurs invalides, timeout NVIDIA, compteur sysfs, JSON Intel tronqué.
- Préférences : fichier corrompu, bornes, unicité, écriture atomique.
- Interface hors écran : dispositions rendues, menus, visibilité minimum, verrouillage,
  taille, ordre, historique, sauvegarde.
- Paquet : structure ar/tar, dépendances, fichiers, permissions et intégrité ZIP.

Les tests avec données simulées ne prouvent pas la compatibilité des pilotes réels.
