#!/bin/sh
set -eu
sudo apt remove monitorbar
printf '\nLes préférences personnelles sont conservées dans ~/.config/monitorbar.\n'
