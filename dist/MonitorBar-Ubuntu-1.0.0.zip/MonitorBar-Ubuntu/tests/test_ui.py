import os
from pathlib import Path
import tempfile
import unittest

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from PyQt5.QtWidgets import QApplication, QMenu
from monitorbar.app import Overlay


class UITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.previous = os.environ.get('XDG_CONFIG_HOME')
        os.environ['XDG_CONFIG_HOME'] = cls.temp.name
        cls.app = QApplication.instance() or QApplication([])

    @classmethod
    def tearDownClass(cls):
        if cls.previous is None:
            os.environ.pop('XDG_CONFIG_HOME', None)
        else:
            os.environ['XDG_CONFIG_HOME'] = cls.previous
        cls.temp.cleanup()

    def setUp(self):
        from monitorbar.settings import normalize
        self.window = Overlay(start_worker=False)
        self.window.cfg = normalize({})
        self.window.changed()

    def tearDown(self):
        self.window.close()

    def test_layouts_render_and_preferences_roundtrip(self):
        for layout in range(3):
            self.window.set_value('layout', layout)
            self.window.cfg['graphs'] = ['CPU', 'RAM', 'GPU']
            self.window.theme('Néon')
            for value in [20, None, 80]:
                self.window.receive({'CPU': value, 'RAM': 60, 'GPU': None}, [], 'GPU non disponible')
            self.app.processEvents()
            pixmap = self.window.grab()
            self.assertFalse(pixmap.isNull())
            self.assertEqual(pixmap.size(), self.window.size())
        self.window.persist()
        self.assertTrue((Path(self.temp.name)/'monitorbar/settings.json').exists())

    def test_visibility_lock_scale_and_order(self):
        for key in ['CPU', 'RAM', 'GPU']:
            self.window.visibility(key)
        self.assertEqual(len(self.window.cfg['indicators']), 1)
        self.window.visibility('CPU')
        self.window.reorder('CPU', True)
        self.assertEqual(self.window.cfg['indicators'][0], 'CPU')
        self.window.scale(100)
        self.assertEqual(self.window.cfg['scale'], 2.5)
        self.window.cfg['locked'] = True
        self.window.scale(-1)
        self.assertEqual(self.window.cfg['scale'], 2.5)

    def test_context_menu_and_graph_history(self):
        menu = QMenu()
        self.window.populate(menu)
        self.assertIn('Carte GPU', [action.text() for action in menu.actions()])
        for i in range(90):
            self.window.receive({'CPU': float(i), 'RAM': None, 'GPU': 0}, [], '')
        self.assertEqual(len(self.window.history['CPU']), 60)
        self.assertEqual(self.window.history['CPU'][0], 30)
        self.window.select_gpu('GPU-other')
        self.assertEqual(len(self.window.history['GPU']), 0)


if __name__ == '__main__':
    unittest.main()
