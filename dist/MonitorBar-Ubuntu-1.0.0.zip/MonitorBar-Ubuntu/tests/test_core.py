import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from monitorbar.metrics import SystemMetrics, cpu_ticks, ram_percent, percent, intel_percent, gpu_sample, discover_gpus
from monitorbar.settings import normalize, save, load


class MetricsTests(unittest.TestCase):
    def test_cpu_guest_not_double_counted(self):
        self.assertEqual(cpu_ticks('cpu 10 2 3 40 5 1 1 0 9 0'), (62, 45))

    def test_cpu_delta_and_counter_reset(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            (path/'meminfo').write_text('MemTotal: 1000 kB\nMemAvailable: 250 kB\n')
            (path/'stat').write_text('cpu 10 0 0 90 0 0 0 0\n')
            metrics = SystemMetrics(path)
            self.assertEqual(metrics.sample(), {'CPU': None, 'RAM': 75.0})
            (path/'stat').write_text('cpu 40 0 0 160 0 0 0 0\n')
            self.assertEqual(metrics.sample()['CPU'], 30.0)
            self.assertIsNone(metrics.sample()['CPU'])
            (path/'stat').write_text('cpu 1 0 0 9 0 0 0 0\n')
            self.assertIsNone(metrics.sample()['CPU'])

    def test_ram_available_includes_cache(self):
        self.assertEqual(ram_percent('MemTotal: 1000 kB\nMemFree: 10 kB\nMemAvailable: 400 kB'), 60)
        self.assertIsNone(ram_percent('MemTotal: 0 kB'))
        self.assertIsNone(ram_percent('MemTotal: 100 kB'))

    def test_unavailable_never_zero(self):
        for value in ['N/A', 'nan', 'inf', '-1', '101', None]:
            self.assertIsNone(percent(value))
        self.assertEqual(percent('0'), 0)
        self.assertEqual(gpu_sample(None)[0], None)

    def test_intel_truncated_stream_and_engine_maximum(self):
        output = '[{"engines":{"Render":{"busy":20},"Video":{"busy":70}}},' + '{"engines":{"Render":{"busy":45}}}, {"partial":'
        self.assertEqual(intel_percent(output), 45)
        self.assertIsNone(intel_percent('Permission denied'))
        self.assertIsNone(intel_percent('{"engines":{"Render":{"busy":"-"}}}'))

    @patch('monitorbar.metrics.run')
    def test_nvidia_and_timeout(self, run):
        device = {'backend': 'nvidia', 'id': 'GPU-test', 'name': 'Test GPU'}
        run.return_value = subprocess.CompletedProcess([], 0, '42\n', '')
        self.assertEqual(gpu_sample(device)[0], 42)
        run.return_value = subprocess.CompletedProcess([], 0, 'N/A', '')
        self.assertIsNone(gpu_sample(device)[0])
        run.side_effect = subprocess.TimeoutExpired('nvidia-smi', 1.5)
        self.assertIsNone(gpu_sample(device)[0])

    @patch('monitorbar.metrics.shutil.which', return_value=None)
    def test_sysfs_discovery_and_reading(self, which):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'card0/device'
            path.mkdir(parents=True)
            (path/'vendor').write_text('0x1002')
            (path/'gpu_busy_percent').write_text('82')
            devices = discover_gpus(Path(directory))
            self.assertEqual(len(devices), 1)
            self.assertEqual(gpu_sample(devices[0])[0], 82)
            (path/'gpu_busy_percent').unlink()
            self.assertIsNone(gpu_sample(devices[0])[0])


class SettingsTests(unittest.TestCase):
    def test_invalid_preferences(self):
        result = normalize({'scale': float('nan'), 'spacing': 999, 'layout': [],
                            'indicators': ['RAM', 'RAM', 'bad', {}], 'graphs': [None],
                            'colors': {'CPU': 'bad'}, 'position': ['bad', 1]})
        self.assertEqual(result['scale'], 1)
        self.assertEqual(result['spacing'], 80)
        self.assertEqual(result['indicators'], ['RAM'])
        self.assertIsNone(result['position'])
        self.assertEqual(normalize({'indicators': []})['indicators'], ['CPU', 'RAM', 'GPU'])

    def test_atomic_roundtrip_and_corrupt_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'settings.json'
            data = normalize({'scale': 1.5, 'position': [42, 100], 'gpu': 'GPU-test'})
            save(data, path)
            self.assertEqual(load(path), data)
            self.assertEqual(list(Path(directory).iterdir()), [path])
            path.write_text('{broken')
            self.assertEqual(load(path), normalize({}))


if __name__ == '__main__':
    unittest.main()
