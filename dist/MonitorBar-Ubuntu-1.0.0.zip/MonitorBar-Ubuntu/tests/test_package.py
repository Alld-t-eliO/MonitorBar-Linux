import io
from pathlib import Path
import tarfile
import unittest
import zipfile
from build_release import build


class PackageTests(unittest.TestCase):
    def test_release_contents_modes_and_dependencies(self):
        build()
        root = Path(__file__).resolve().parents[1]
        data = (root/'dist/monitorbar_1.0.0_all.deb').read_bytes()
        self.assertEqual(data[:8], b'!<arch>\n')
        position, members = 8, {}
        while position < len(data):
            header = data[position:position+60]
            size = int(header[48:58])
            name = header[:16].decode().strip().rstrip('/')
            members[name] = data[position+60:position+60+size]
            position += 60+size+(size % 2)
        self.assertEqual(members['debian-binary'], b'2.0\n')
        with tarfile.open(fileobj=io.BytesIO(members['control.tar.gz'])) as archive:
            self.assertIn(b'python3-pyqt5', archive.extractfile('./control').read())
        with tarfile.open(fileobj=io.BytesIO(members['data.tar.gz'])) as archive:
            self.assertEqual(archive.getmember('./usr/bin/monitorbar').mode, 0o755)
            self.assertIsNotNone(archive.getmember('./usr/share/monitorbar/monitorbar/app.py'))
        with zipfile.ZipFile(root/'dist/MonitorBar-Ubuntu-1.0.0.zip') as archive:
            self.assertIsNone(archive.testzip())
            self.assertIn('MonitorBar-Ubuntu/dist/monitorbar_1.0.0_all.deb', archive.namelist())


if __name__ == '__main__':
    unittest.main()
